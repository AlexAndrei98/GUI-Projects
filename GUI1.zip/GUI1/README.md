Alexandru Andrei

Developed using VS Code on MacOS.

The webpage contains a horizontal bar graphs the can have 10 candidates at most. This decision was made for improving the user experience
Furthermore each time a candidate gets added a new div get created in the webpage. (Attention: if the name contains more than 2 blank spaces the bar will be displayed incorrectly). 
Every time a div gets clicked then the updatesVotes(div_id) function which takes the div id to update the information about a certain candidates. Then the updateWidth() functions gets called on all of the divs that are candidates on the pages and they all get resized according to the updated votes.


Developed in Young with ❤️ by Alex